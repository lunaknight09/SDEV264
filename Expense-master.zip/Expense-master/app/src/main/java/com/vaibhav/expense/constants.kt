package com.vaibhav.expense

const val table_name = "transaction_table"
const val database_name = "transaction_database"